use master
go

-- Create the Stocks database
create database stocks
go

-- Turn on the following options for this new database
-- Allow use of the bulkcopy program "bcp".
-- Truncate the transaction log when a checkpoint command is issued.
-- Periodically try to shrink the database 

sp_dboption 'stocks', 'bulkcopy', 'true'
go
sp_dboption 'stocks', 'trunc. log', 'true'
go
sp_dboption 'stocks', 'autoshrink', 'true'
go



--
-- Create the stocks_login account
--

sp_addlogin 'stocks_login', 'password', 'stocks'
go
sp_addsrvrolemember 'stocks_login', 'sysadmin'
go

use stocks
go

sp_grantdbaccess 'stocks_login', 'stocks_login'
go
sp_addrolemember 'db_owner', 'stocks_login'
go



--
-- Tables, constraints, indexes and defaults
-- Note: the DML presented here was not generated natively from SQL Server 7.
-- It was cleaned up by hand to incorporate everything into a single create table stmt.
--


create table Accounts (
	AccountID	int IDENTITY (5000, 1) NOT NULL 
				constraint PK_AccountID PRIMARY KEY ,
	Password	varchar (50) NOT NULL ,
	FirstName	varchar (30) NOT NULL ,
	LastName	varchar (30) NOT NULL ,
	Balance		money NOT NULL default(10000),
	DateOpened	datetime NULL default(getdate()),
	email		varchar (50) NOT NULL 
				constraint IX_Email UNIQUE,
	Closed		bit NOT NULL default(0) 
)
go

create table dbo.stocks (
	ticker 		char (6) NOT NULL 
				constraint PK_StockSymbols_Ticker PRIMARY KEY,
	company 	varchar (60) NOT NULL ,
	exchange 	char (4) NOT NULL 
) 
go

create table dbo.CurrentPrices (
	ticker		char(6) NOT NULL
				constraint PK_CurrentPrices_Ticker PRIMARY KEY
				references stocks(ticker),
	last		money NOT NULL
)
go

CREATE TABLE dbo.Fundamentals (
	Ticker 			char (6) NOT NULL
					constraint PK_Fundamentals_Ticker PRIMARY KEY
					references stocks(ticker),
	MarketCap		money NULL ,
	Sales			money NULL ,
	Price			money NULL ,
	DailyDollarVol	money NULL ,
	SalesGrowth		float NULL ,
	EPSGrowth		float NULL ,
	NetProfitMargin float NULL ,
	InsiderShares	float NULL ,
	CashFlowPerShare money NULL ,
	PE				money NULL ,
	EPS_TTM			money NULL ,
	Date_Q1			datetime NULL ,
	EPS_Q1			money NULL ,
	Date_FY1		datetime NULL ,
	EPS_FY1			money NULL ,
	EPS_FY2			money NULL ,
	Status			int NOT NULL default(0) 
)
GO

CREATE TABLE dbo.Positions (
	PositionID 	int IDENTITY (10000, 1) NOT NULL 
				constraint PK_PositionsID PRIMARY KEY NONCLUSTERED,
	AccountID 	int NOT NULL 
				references Accounts(AccountID),
	Ticker 		char (6) NOT NULL 
				references stocks(Ticker),
	Shares 		int NOT NULL ,
	Price 		money NOT NULL ,
	Commission 	money NOT NULL default(0),
	PurchaseDate 	datetime NOT NULL default(getdate())
)
GO

create clustered index IX_AccountID_Ticker on dbo.Positions(AccountID, Ticker)
go


CREATE TABLE dbo.TransactionTypes (
	TransactionTypeID tinyint NOT NULL 
					constraint PK_TxTypes PRIMARY KEY,
	Description		char (20) NOT NULL 
) 
GO


CREATE TABLE dbo.Transactions (
	TransactionID 	int IDENTITY (1, 1) NOT NULL 
					constraint PK_TxID PRIMARY KEY NONCLUSTERED,
	AccountID 		int NOT NULL 
					references Accounts(AccountID),
	Ticker 			char (6) NOT NULL 
					references stocks(ticker),
	Shares 			char (10) NOT NULL ,
	TransactionTypeID tinyint NOT NULL 
					references TransactionTypes(TransactionTypeID),
	DateRecorded 	datetime NOT NULL default(getdate()),
	DateExecuted 	datetime NULL ,
	PositionID 		int NULL 
)
GO

create clustered index IX_AccountID_Ticker on dbo.Transactions(AccountID, Ticker)
go


--
-- Stored procedures
--

CREATE Procedure Account_Add
(
	@FirstName varchar(30),
	@LastName varchar(30),
	@Password varchar(15),
	@EMail varchar(50),
	@Balance money,
	@retval int output		-- AccountID
) 
As
	insert into Accounts (FirstName, LastName, Password, Balance, email)
	values (@FirstName, @LastName, @Password, @Balance, @email)
	
	select @retval = @@IDENTITY
GO


CREATE Procedure Account_Summary
(
	@AccountID integer
)
as
	declare @bal money
	select @bal = balance 
	from accounts
	where AccountID = @AccountID

	select sum(p.last / 100.0 * shares) as MarketValue,
		sum((price/100.0 * shares) + commission) as TotalInvestment,
		@bal as CashBalance		-- we're using max even though there is only one balance
	from positions t, CurrentPrices as p, stocks as ss
	where t.AccountID = @AccountID
	and t.ticker = p.ticker
	and t.ticker = ss.ticker
GO

CREATE Procedure Account_VerifyLogin
(
	@EMail varchar(50),
	@Password varchar(50),
	@AccountID int output,
	@FullName varchar(100) output
)
As
	select @AccountID = AccountID, 
		@FullName = FirstName + ' ' + LastName
	from accounts
	where email = @EMail
	and Password = @Password

	return @@ROWCOUNT	-- 0 means not found, 1 means it matched
GO


create Procedure Broker_Buy
(
	@TxID integer,
	@AccountID integer,
	@Ticker char(12),
	@Shares integer,
	@Price money,
	@Commission money,
	@retval integer output		-- PositionID
)
as
    insert into Positions (AccountID, Ticker, Shares, Price, Commission)
    values (@AccountID, @Ticker, @Shares, @Price, @Commission)
    select @retval = @@IDENTITY
        
    -- update the corresponding record in Transactions
    update transactions
    set TransactionTypeID = 3, DateExecuted = getdate(), PositionID = @retval        
    where TransactionID = @TxID
GO


CREATE Procedure Broker_Sell
(
	@TxID integer,
	@Price money,
	@Commission money,
	@retval int output
)
as
	select @retval = 0

	declare @AccountID integer
	declare @PositionID integer
	declare @Ticker char(12)
	declare @Shares integer
	declare @TotalSharesOwned integer

	select @AccountID = AccountID, @Ticker = Ticker, @Shares = Shares
	from Transactions where TransactionID = @TxID

	select @TotalSharesOwned = sum(Shares)
	from Positions
	where Ticker = @Ticker
	and AccountID = @AccountID

	if @Shares > @TotalSharesOwned or @TotalSharesOwned is null
	begin
		raiserror ('Request to sell too many shares aborted.', 16, 1)
		rollback tran
		return
	end

	-- Calculate the gain
	-- Positions uses pennies/Accounts uses Dollars
	update accounts
	set Balance = Balance + (@Shares * @Price / 100.0) - @Commission
	where AccountID = @AccountID
       
        -- Update the corresponding record in Transactions
        update transactions
        set TransactionTypeID = 4, DateExecuted = getdate()        
        where TransactionID = @TxID

	-- It's the caller's responsibility to update the appropriate position entries
	select @retval = 1
GO


CREATE Procedure Position_ListForAdjustment
(
	@AccountID integer,
	@ticker varchar(15)
)
As
	select *
	from positions
	where AccountID = @AccountID
	and ticker = @ticker
GO


CREATE PROCEDURE Position_ListForSale
(
	@AccountID integer
)
as
	select upper(rtrim(positions.Ticker)) as ticker, 
		sum(shares) as shares, 
		avg(last) / 100.0 as price
	from positions, CurrentPrices
	where accountid = @AccountID
	and positions.ticker = CurrentPrices.ticker
	group by positions.ticker
GO


CREATE Procedure Position_ListSummary
(
	@AccountID integer	
)
As
	set nocount on	
	
	select upper(ticker) as Ticker, sum(shares) as TotalShares,
		sum(commission) as TotalCommission
	into #PositionsList
	from Positions
	where accountid = @AccountID
	group by ticker		

	select upper(t.ticker) as ticker, 
		company, 
		min(TotalShares) as SharesOwned,
		convert(money, (      (min(Last)/100.0)      )) as LastPrice,
		convert(money, (      (sum((shares / convert(real, ts.TotalShares)) * price) / 100.0) + (min(TotalCommission / TotalShares))    )) as AvgPricePaid	-- See the XLS spreadsheet for an explaination of this line
	from positions t, CurrentPrices as p, stocks as ss, #PositionsList ts
	where t.AccountID = @AccountID
	and t.ticker = p.ticker
	and t.ticker = ss.ticker
	and t.ticker = ts.ticker
	group by t.ticker, company
	return
GO


CREATE PROCEDURE Ticker_Fundamentals
(
	@Ticker varchar(12)
)
as
	select status, fundamentals.ticker, company, exchange, 
		rtrim(convert(varchar(20), MarketCap, 1)) as MarketCap, 	--$M
		rtrim(convert(varchar(20), Sales, 1)) as Sales,		--$M
		rtrim(convert(varchar(20), Price, 1)) as Price,		--$ per share
		rtrim(convert(varchar(20), DailyDollarVol, 1)) as DailyDollarVol,	--$M
		ltrim(str(SalesGrowth, 9, 1)) as SalesGrowth,	--%
		ltrim(str(EPSGrowth, 9, 1)) as EPSGrowth,	--%
		ltrim(str(NetProfitMargin, 9, 1)) as NetProfitMargin,	--%
		ltrim(str(InsiderShares, 9, 0)) as InsiderShares, 	--%
		ltrim(str(CashFlowPerShare, 9, 2)) as CashFlowPerShare,	--$ per share
		ltrim(str(pe, 9, 1)) as PE			--$ per share
	from fundamentals, stocks
	where fundamentals.ticker = @Ticker
	and fundamentals.ticker = stocks.ticker
GO

CREATE Procedure Ticker_GetPrice
(
	@Ticker char(12),
	@retval money output		-- Price
)
as
    --Lookup current price for this ticker
    select @retval = last
    from CurrentPrices
    where ticker = @ticker
GO


CREATE PROCEDURE Ticker_ListByCompany
(
	@Company varchar(30)
)
AS
	declare @@NewCompany varchar(31)

	Select @@NewCompany = @Company + '%'

	select rtrim(ticker) as ticker, rtrim(company) as company, rtrim(exchange) as exchange
	from stocks
	where company like @@NewCompany
GO


CREATE PROCEDURE Ticker_ListByTicker
(
	@Ticker varchar(12)
)
AS
	declare @@NewTicker varchar(31)

	Select @@NewTicker = @Ticker + '%'

	select rtrim(ticker) as ticker, rtrim(company) as company, rtrim(exchange) as exchange
	from stocks
	where ticker like @@NewTicker
GO


CREATE Procedure Ticker_VerifySymbol
(
	@Ticker varchar(12),
	@retval int output
)
As
	select @retval = count(ticker) 
	from stocks
	where ticker=@Ticker
GO

create proc Tx_GetByID 
(
	@TxID integer
)
as
	select *
	from transactions
	where TransactionID = @TxID
GO


CREATE PROCEDURE Tx_AddBuyOrder
(
	@AccountID int,
	@Ticker varchar(12),
	@Shares int,
	@retval int output	-- TxID
)
as
	insert into Transactions (AccountID, Ticker, Shares, TransactionTypeID)
	values (@AccountId, @Ticker, @Shares, 1)

	select @retval = @@IDENTITY
GO


CREATE PROCEDURE Tx_AddSellOrder
(
	@AccountID int,
	@Ticker varchar(12),
	@Shares int,
	@retval int output		--TxID
)
as
	insert into Transactions (AccountID, Ticker, Shares, TransactionTypeID)
	values (@AccountId, @Ticker, @Shares, 2)

	select @retval = @@IDENTITY
GO


create proc Tx_SetTxType
(
	@TxID integer,
	@TxTypeID integer
)
as
	update transactions
	set TransactionTypeID = @TxTypeID, DateExecuted = getdate()
	where TransactionID = @TxID
GO

--
-- Triggers
--

CREATE Trigger tr_accounts_d
On dbo.Accounts
For Delete
As
	-- Cascade delete this accounts positions and transaction history
	delete Positions
	from Positions, deleted
	where Positions.AccountID = deleted.AccountID

	delete Transactions
	from Transactions, deleted
	where Transactions.AccountID = deleted.AccountID
GO


CREATE Trigger tr_positions_iu
On dbo.Positions
For Insert, Update 
As
	if update(Price)
	begin
		declare @result int
		declare @UserID int
		
       	-- Abort if this new ExpenseItem exceeds predefined individual limits
        declare @Balance money
        declare @AccountID integer

		select @Balance = Balance, @AccountID = i.AccountID
		from inserted i, Accounts
        where i.AccountID = Accounts.AccountID
                   
        declare @debit money
        select @debit = (shares * price / 100.0) + commission
        from inserted
		
		if @debit > @Balance
		begin
			raiserror ('Account has insufficient funds for this purchase', 16, 1)
			rollback tran
			return
		end
		
		update accounts
		set Balance = Balance - @debit
		where AccountID = @AccountID       			
	end
GO


-- Dropping the DRI. The desired effect is enforced by triggers

alter table Accounts	NOCHECK CONSTRAINT ALL
alter table Positions	NOCHECK CONSTRAINT ALL
alter table Transactions NOCHECK CONSTRAINT ALL
alter table Fundamentals NOCHECK CONSTRAINT ALL
alter table CurrentPrices NOCHECK CONSTRAINT ALL
go

-- Run this occasionally to simulate price changes

create proc SimulatePriceMovement
as
	declare @direction integer

	if datepart(mi, getdate()) > 30 
		select @direction = -1
	else
		select @direction = 1

	declare @percent float
	select @percent = (datepart(mi, getdate()) % 30) * .01

	update currentprices
	set last = cast(last+(@direction*@percent*last) as integer) + (convert(int, ((last+(@direction*@percent*last) - cast(last+(@direction*@percent*last) as integer)) * 1000)) / 125) * .125
go

