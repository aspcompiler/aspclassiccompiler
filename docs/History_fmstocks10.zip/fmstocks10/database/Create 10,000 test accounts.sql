set nocount on

delete from accounts where password='ta'
go

declare @i integer
select @i = 1

declare @email varchar(10)
declare @accountid integer
declare @txid integer
declare @foo integer

select getdate()
while (@i <= 10000)
begin
	select @email = rtrim('ta' + convert(varchar(10), @i))
	exec Account_Add 'Test', 'Account', 'ta', @email, 10000, @accountid output
	exec Tx_AddBuyOrder @accountid, 'SBUX', 10, @txid output
	exec Broker_Buy @txid, @accountid, 'SBUX', 10, 3256.25, 9.95, @foo output

	exec Tx_AddBuyOrder @accountid, 'MSFT', 5, @txid output
	exec Broker_Buy @txid, @accountid, 'MSFT', 5, 10125, 9.95, @foo output

	if @i % 1000 = 0 print @i

	select @i = @i + 1
end
select getdate()