function m_over(x) 
{
	if(x == null)
		x= window;
	x.event.srcElement.style.background="#003399";
	x.event.srcElement.style.color = "yellow";
	x.event.srcElement.style.cursor = "hand";
}

function m_out(x) 
{
	if(x == null)
		x= window;
	x.event.srcElement.style.background="#0066CC";
	x.event.srcElement.style.color = "white";
	x.event.srcElement.style.cursor = "default";
}

function m_click(dest) 
{
	window.navigate(dest);
}


function n_over(x) 
{
	if(x == null)
		x= window;
	x.event.srcElement.style.background="#0066CC";
	x.event.srcElement.style.color = "white";
	x.event.srcElement.style.cursor = "hand";
}

function n_out(x) 
{
	if(x == null)
		x= window;
	x.event.srcElement.style.background="#99CCFF";
	x.event.srcElement.style.color = "sienna";
	x.event.srcElement.style.cursor = "default";
}

function handleMouseover() {
	eSrc = window.event.srcElement;
	eSrcTag=eSrc.tagName.toUpperCase();
	if (eSrcTag == "A") eSrc.style.textDecoration = "underline";
}

function handleMouseout() {
	eSrc = window.event.srcElement;
	eSrcTag=eSrc.tagName.toUpperCase();
	if (eSrcTag == "A") eSrc.style.textDecoration = "";
}
function openDialog(URL)
{
	return window.open(URL,"test","resizable=yes,status=no,toolbar=no,location=no");
}
document.onmouseover=handleMouseover;
document.onmouseout=handleMouseout;

window.onload=window_onload;

function window_onload()
{
	var title = top.document.all("title");
	
	if (title != null)
	{
		title.filters[0].Apply(); 
		title.innerHTML = document.title; 
		title.filters[0].Play(); 
	}	
}
